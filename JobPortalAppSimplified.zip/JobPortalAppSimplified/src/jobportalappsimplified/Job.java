/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jobportalappsimplified;

class Job {
    private int jobId;
    private String jobTitle;
    private String description;
    private String companyName;

    public Job(int jobId, String jobTitle, String description, String companyName) {
        this.jobId = jobId;
        this.jobTitle = jobTitle;
        this.description = description;
        this.companyName = companyName;
    }

    public int getJobId() {
        return jobId;
    }

    @Override
    public String toString() {
        return "Job ID: " + jobId + ", Title: " + jobTitle + ", Company: " + companyName;
    }
}
