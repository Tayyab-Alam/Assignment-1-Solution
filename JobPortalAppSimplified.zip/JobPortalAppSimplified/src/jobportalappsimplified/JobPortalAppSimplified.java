/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jobportalappsimplified;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JobPortalAppSimplified {
    private List<Job> jobs = new ArrayList<>();
    private List<JobApplication> applications = new ArrayList<>();

    public static void main(String[] args) {
        JobPortalAppSimplified portalApp = new JobPortalAppSimplified();
        portalApp.run();
    }

    // Main run method to interact with the user
    public void run() {
        Scanner scanner = new Scanner(System.in);

        // Adding sample jobs
        jobs.add(new Job(1, "Software Engineer", "Develop software applications.", "TechCorp"));
        jobs.add(new Job(2, "Data Analyst", "Analyze data patterns.", "DataSolutions"));

        // Display available jobs
        displayJobs();

        // Apply for a job
        System.out.print("Enter your name: ");
        String userName = scanner.nextLine();
        System.out.print("Enter the Job ID you want to apply for: ");
        int jobId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter your resume text: ");
        String resumeText = scanner.nextLine();

        // Process job application
        applyForJob(userName, jobId, resumeText);
    }

    // Displays available jobs
    private void displayJobs() {
        System.out.println("Available Jobs:");
        for (Job job : jobs) {
            System.out.println(job);
        }
    }

    // Apply for a job method
    private void applyForJob(String userName, int jobId, String resumeText) {
        Job job = findJobById(jobId);
        if (job == null) {
            System.out.println("Job not found.");
            return;
        }
        JobApplication application = new JobApplication(userName, job, resumeText);
        applications.add(application);
        System.out.println("Application submitted successfully! Application ID: " + application.getApplicationId());
    }

    // Helper method to find a job by ID
    private Job findJobById(int jobId) {
        for (Job job : jobs) {
            if (job.getJobId() == jobId) {
                return job;
            }
        }
        return null;
    }
}

