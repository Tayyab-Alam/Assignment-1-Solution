/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jobportalappsimplified;

class JobApplication {
    private static int applicationCounter = 1;
    private int applicationId;
    private String userName;
    private Job job;
    private String resumeText;

    public JobApplication(String userName, Job job, String resumeText) {
        this.applicationId = applicationCounter++;
        this.userName = userName;
        this.job = job;
        this.resumeText = resumeText;
    }

    public int getApplicationId() {
        return applicationId;
    }

    @Override
    public String toString() {
        return "Application ID: " + applicationId + ", User: " + userName + ", Job: " + job;
    }
}
