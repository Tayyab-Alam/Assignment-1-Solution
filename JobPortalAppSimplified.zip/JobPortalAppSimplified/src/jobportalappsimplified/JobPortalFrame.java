/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jobportalappsimplified;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class JobPortalFrame extends javax.swing.JFrame {
    private List<Job> jobs = new ArrayList<>();
    private List<JobApplication> applications = new ArrayList<>();
    private int applicationCounter = 1; // Counter for application IDs

    public JobPortalFrame() {
        initComponents();
        initJobs();  // Initialize sample jobs
    }

    // Initialize sample jobs
    private void initJobs() {
        jobs.add(new Job(1, "Software Engineer", "Develop software applications.", "TechCorp"));
        jobs.add(new Job(2, "Data Analyst", "Analyze data patterns.", "DataSolutions"));
        updateJobList(); // Update GUI with available jobs
    }

    // Update job list display
    private void updateJobList() {
        StringBuilder jobList = new StringBuilder("<html>Available Jobs:<br>");
        for (Job job : jobs) {
            jobList.append(job.toString()).append("<br>");
        }
        jobList.append("</html>");
        jLabelJobs.setText(jobList.toString());
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jLabelJobs = new javax.swing.JLabel();
        jLabelName = new javax.swing.JLabel("Enter your name:");
        jTextFieldName = new JTextField(15);
        jLabelJobId = new javax.swing.JLabel("Enter the Job ID you want to apply for:");
        jTextFieldJobId = new JTextField(5);
        jLabelResume = new javax.swing.JLabel("Enter your resume text:");
        jTextAreaResume = new JTextArea(5, 20);
        jButtonSubmit = new JButton("Submit Application");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jLabelJobs.setText("Available Jobs will be displayed here");

        jButtonSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                submitApplication();
            }
        });

        // Layout setup
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(jLabelJobs)
                .addComponent(jLabelName)
                .addComponent(jTextFieldName)
                .addComponent(jLabelJobId)
                .addComponent(jTextFieldJobId)
                .addComponent(jLabelResume)
                .addComponent(jTextAreaResume)
                .addComponent(jButtonSubmit)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(jLabelJobs)
                .addComponent(jLabelName)
                .addComponent(jTextFieldName)
                .addComponent(jLabelJobId)
                .addComponent(jTextFieldJobId)
                .addComponent(jLabelResume)
                .addComponent(jTextAreaResume)
                .addComponent(jButtonSubmit)
        );

        pack();
    }

    private void submitApplication() {
        String userName = jTextFieldName.getText().trim();
        String jobIdText = jTextFieldJobId.getText().trim();
        String resumeText = jTextAreaResume.getText().trim();

        // Validate input
        if (userName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your name.");
            return;
        }
        if (jobIdText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the Job ID.");
            return;
        }
        if (resumeText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your resume text.");
            return;
        }

        // Convert Job ID to integer
        int jobId;
        try {
            jobId = Integer.parseInt(jobIdText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid Job ID. Please enter a number.");
            return;
        }

        // Find the job based on ID
        Job job = findJobById(jobId);
        if (job == null) {
            JOptionPane.showMessageDialog(this, "Job not found.");
            return;
        }

        // Create and store the job application
        JobApplication application = new JobApplication(userName, job, resumeText);
        applications.add(application);

        // Show confirmation message
        JOptionPane.showMessageDialog(this, "Application submitted successfully! Application ID: " + application.getApplicationId());
    }

    // Helper method to find a job by ID
    private Job findJobById(int jobId) {
        for (Job job : jobs) {
            if (job.getJobId() == jobId) {
                return job;
            }
        }
        return null;
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JobPortalFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel jLabelJobs;
    private javax.swing.JLabel jLabelName;
    private javax.swing.JLabel jLabelJobId;
    private javax.swing.JLabel jLabelResume;
    private javax.swing.JTextField jTextFieldName;
    private javax.swing.JTextField jTextFieldJobId;
    private javax.swing.JTextArea jTextAreaResume;
    private javax.swing.JButton jButtonSubmit;
    // End of variables declaration                   
}

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

